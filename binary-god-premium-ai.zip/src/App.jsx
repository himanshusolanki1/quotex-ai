import React, { useState, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function BinaryGodPremiumAI() {
  const [marketPair, setMarketPair] = useState("");
  const [stage, setStage] = useState("input");
  const [timer, setTimer] = useState(30);
  const [signal, setSignal] = useState(null);
  const [confidence, setConfidence] = useState(0);
  const [loading, setLoading] = useState(false);
  const pressTimer = useRef(null);

  const showSignal = (direction) => {
    setLoading(true);
    setSignal(null);
    setTimeout(() => {
      setSignal(direction);
      setConfidence(100);
      setLoading(false);
      setStage("result");
    }, 2500);
  };

  const handlePressStart = () => {
    pressTimer.current = setTimeout(() => {
      showSignal("DOWN");
    }, 500);
  };

  const handlePressEnd = () => {
    if (pressTimer.current) {
      clearTimeout(pressTimer.current);
      if (!signal && !loading) {
        showSignal("UP");
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black to-gray-900 text-white flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-gray-800 border border-gray-700 rounded-2xl shadow-xl">
        <CardContent className="p-6 space-y-6">
          <div className="flex flex-col items-center space-y-2">
            <img
              src="/binarygod-logo.png"
              alt="Binary God Premium AI Logo"
              className="w-24 h-24 rounded-full border-2 border-yellow-400 shadow-lg"
            />
            <img
              src="/robot-assistant.png"
              alt="AI Assistant"
              className="w-20 h-20"
            />
            <h1 className="text-xl font-bold text-yellow-400">
              Binary God Premium AI
            </h1>
            <p className="text-sm text-gray-400">Powered by Smart Trading Logic™</p>
          </div>

          {stage === "input" && (
            <div className="space-y-4">
              <Input
                placeholder="Enter Market + Pair (e.g. Quotex - EUR/USD)"
                value={marketPair}
                onChange={(e) => setMarketPair(e.target.value)}
              />
              <Button
                className="w-full bg-yellow-500 hover:bg-yellow-600 text-black"
                onClick={() => setStage("dashboard")}
                disabled={!marketPair}
              >
                Continue
              </Button>
            </div>
          )}

          {stage === "dashboard" && (
            <div className="space-y-4">
              <p className="text-center text-sm text-gray-300">
                Market & Pair: <span className="font-semibold">{marketPair}</span>
              </p>
              <Input
                type="number"
                placeholder="Set Timer in Seconds"
                value={timer}
                onChange={(e) => setTimer(Number(e.target.value))}
              />
              <Button
                className="w-full bg-green-500 hover:bg-green-600 text-white"
                onMouseDown={handlePressStart}
                onMouseUp={handlePressEnd}
                onTouchStart={handlePressStart}
                onTouchEnd={handlePressEnd}
              >
                Hold for DOWN / Tap for UP
              </Button>
            </div>
          )}

          {loading && (
            <div className="space-y-4 text-center animate-pulse">
              <p className="text-sm text-gray-300">Connecting to Quotex AI server...</p>
              <p className="text-xs text-gray-500">Authenticating...</p>
              <p className="text-xs text-gray-500">Analyzing Pattern...</p>
            </div>
          )}

          {stage === "result" && signal && !loading && (
            <div className="space-y-4 text-center">
              <p className="text-xl font-medium">Signal for:</p>
              <p className="text-lg text-gray-300">{marketPair}</p>
              <p
                className={`text-4xl font-bold ${
                  signal === "UP" ? "text-green-400" : "text-red-500"
                } animate-pulse`}
              >
                {signal}
              </p>
              <p className="text-sm text-gray-400">Confidence: {confidence}%</p>
              <Button
                className="w-full bg-blue-500 hover:bg-blue-600"
                onClick={() => setStage("dashboard")}
              >
                Generate New Signal
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
