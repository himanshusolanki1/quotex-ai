export function Input({ className = "", ...props }) {
  return <input className={`w-full p-2 rounded-xl bg-gray-700 text-white border border-gray-600 placeholder-gray-400 ${className}`} {...props} />;
}