import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import BinaryGodPremiumAI from './App.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BinaryGodPremiumAI />
  </React.StrictMode>,
)
